import { useState } from 'react';
import Contact from '../Contact';
import './contactList.css';

const ContactList = ({ contacts, onSetContacts, onSetEditModalIsOn }) => {
  const [checkedIds, setCheckedIds] = useState([]);

  const checkAll = (e) => {
    const { checked } = e.target;
    if (checked) {
      const checkedIdsArray = contacts.map(contact => contact.id);
      setCheckedIds(checkedIdsArray);
    }
    else setCheckedIds([])
  }

  const toggleContactFromList = (e, contactId) => {
    const { checked } = e.target;
    if (!checked) {
      setCheckedIds((ids) => {
        const newIdsArray = ids.filter(id => contactId !== id);
        return newIdsArray;
      });
    }
    else {
      setCheckedIds((ids) => {
        const withNewId = [...ids, contactId];
        return withNewId;
      });
    }
  }

  const handleDeleteChecked = () => {
    if (checkedIds.length === contacts.length) {
      onSetContacts([]);
      localStorage.clear();
    }
    else {
      onSetContacts((contacts) => {
        const filteredList = contacts.filter(contact => !checkedIds.includes(contact.id));
        localStorage.setItem("contacts", JSON.stringify(filteredList));
        return filteredList;
      });
    }
    setCheckedIds([])
  }

  const handleDeleteContact = (contactId) => {
    // Filter the contacts array to remove the contact with the specified ID
    const updatedContacts = contacts.filter((contact) => contact.id !== contactId);

    // Update the contacts state and local storage with the updated list
    onSetContacts(updatedContacts);

    // You may also want to update local storage here
    localStorage.setItem("contacts", JSON.stringify(updatedContacts));
  };

  return (
    <table>
      <caption>Contacts</caption>
      <thead>
        <tr>
          <th><input type="checkbox" onChange={checkAll} checked={checkedIds.length && checkedIds.length === contacts.length} /></th>
          <th><i className="fa fa-trash-o delete-all" onClick={handleDeleteChecked} /></th>
          <th></th>
          <th>Name</th>
          <th>Phone number</th>
        </tr>
      </thead>
      <tbody>
        {
          contacts.map((contact, i) => <Contact onSetEditModalIsOn={onSetEditModalIsOn} onDeleteContact={handleDeleteContact} onToggleContactFromList={toggleContactFromList} checkedIds={checkedIds} contactData={contact} key={`contact-${i}`} />)
        }

      </tbody>
    </table>
  )
}

export default ContactList;